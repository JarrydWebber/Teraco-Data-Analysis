Make changes to config.ini as required to point the program to the required folder.

Ensure that the information in the Nameing_List.csv is correct for your site. It includes a short name, the name of the measurement in the raw data, the type of data it is, and the energy flow associated with the data.

If it is your first time running the program, please run installation.bat, which will install the required python packages.
To run the analysis, excecute Run.bat.